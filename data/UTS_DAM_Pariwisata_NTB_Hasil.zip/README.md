# UTS Data Acquisition & Management — Pariwisata NTB

## Topik
Analisis jumlah kunjungan wisatawan berdasarkan jenis wisatawan di Provinsi Nusa Tenggara Barat.

## Dataset utama
Satu Data NTB — Jumlah Kunjungan Wisatawan berdasarkan Jenis Wisatawan:
https://data.ntbprov.go.id/dataset/9e270f88-a604-4640-a4f0-24c996122b92/show

File asli yang disertakan: `data/raw/dataset_kunjungan_wisatawan_ntb_asli.xlsx`

## Metode akuisisi
1. Dataset terbuka: file Excel Satu Data NTB (300 baris, 7 kolom).
2. API: Open-Meteo Historical Weather API, data cuaca harian titik Mataram tahun 2024.
3. Web scraping: halaman detail Satu Data NTB, hanya jika robots.txt mengizinkan.

## Struktur
- `data/raw/`: dataset Excel asli dan hasil mentah API/scraping.
- `data/processed/`: data API yang dinormalisasi dan hasil merge.
- `metadata/`: provenance, MD5, Data Ethics Checklist, bukti robots.
- `UTS_Data_Acquisition_Pariwisata_NTB.ipynb`: notebook utama.

## Cara menjalankan di Google Colab
1. Upload ZIP ke Google Drive atau ekstrak pada komputer.
2. Buka notebook `.ipynb` dengan Google Colab.
3. Isi identitas mahasiswa dan email kampus pribadi pada sel persiapan.
4. Pastikan file XLSX tersedia pada `data/raw`; bila tidak, notebook meminta upload.
5. Jalankan semua sel berurutan.
6. Periksa output API, robots.txt, scraping, provenance, dan merge.
7. Jangan lanjutkan scraping bila robots.txt melarang URL target. Pilih halaman statis lain yang diizinkan dan dokumentasikan.
8. Simpan notebook setelah seluruh sel dijalankan.

## Catatan kualitas dan etika
Dataset yang diberikan berisi 300 baris dan 7 kolom. Terdapat satu variasi salah eja kategori `Wisatawan Mancaegara`, yang distandardisasi hanya pada salinan analisis; file mentah tidak diubah. Metadata portal menyatakan lisensi `License Not Specified`, sehingga izin penggunaan ulang harus diklarifikasi. API cuaca pada koordinat Mataram tidak mewakili seluruh NTB.

## GitHub
Unggah notebook, folder `data`, `metadata`, dan README setelah semua akuisisi berhasil. Jangan unggah token, password, atau file kredensial.
